# Dr. Mohith S: portfolio

Static site: `index.html` (everything inline), `vercel.json`, `og-image.png`.

## Deploy (free)
1. GitHub: new repository -> Add file -> Upload files -> drop all 3 files -> Commit.
2. Vercel: Add New -> Project -> Import the repo -> Framework Preset "Other" -> no build command -> Deploy.
3. Vercel project -> Analytics -> Enable Web Analytics.
4. In `index.html` replace `YOUR-SITE.vercel.app` (2 places) with your real address, commit again.

## Tracking links (free, shows separately in Analytics -> Pages)
- LinkedIn profile website field: https://YOUR-SITE.vercel.app/li
- X bio link:                     https://YOUR-SITE.vercel.app/x
- Email signature:                https://YOUR-SITE.vercel.app/mail
- WhatsApp status / bio:          https://YOUR-SITE.vercel.app/wa
